print("Jogos por plataformas")
print("Jogos de pc! ")
for jogo in jogos[0]
    print(jogo)
    
print("\nJogos de Ps4! '')
for jogo in jogos[1]
    print(jogo)
    
print('\n jogos de XBOX! ')
for jogo in jogos[1]
    print\jogo)